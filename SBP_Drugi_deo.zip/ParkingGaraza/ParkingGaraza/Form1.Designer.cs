﻿
namespace ParkingGaraza
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prikazioperaterabtn = new System.Windows.Forms.Button();
            this.prikazivozilo = new System.Windows.Forms.Button();
            this.dodajoperatera = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // prikazioperaterabtn
            // 
            this.prikazioperaterabtn.Location = new System.Drawing.Point(53, 25);
            this.prikazioperaterabtn.Name = "prikazioperaterabtn";
            this.prikazioperaterabtn.Size = new System.Drawing.Size(158, 23);
            this.prikazioperaterabtn.TabIndex = 0;
            this.prikazioperaterabtn.Text = "PrikaziOperatera";
            this.prikazioperaterabtn.UseVisualStyleBackColor = true;
            this.prikazioperaterabtn.Click += new System.EventHandler(this.prikazioperaterabtn_Click);
            // 
            // prikazivozilo
            // 
            this.prikazivozilo.Location = new System.Drawing.Point(53, 54);
            this.prikazivozilo.Name = "prikazivozilo";
            this.prikazivozilo.Size = new System.Drawing.Size(158, 23);
            this.prikazivozilo.TabIndex = 1;
            this.prikazivozilo.Text = "PrikaziVozilo";
            this.prikazivozilo.UseVisualStyleBackColor = true;
            this.prikazivozilo.Click += new System.EventHandler(this.prikazivozilo_Click);
            // 
            // dodajoperatera
            // 
            this.dodajoperatera.Location = new System.Drawing.Point(53, 84);
            this.dodajoperatera.Name = "dodajoperatera";
            this.dodajoperatera.Size = new System.Drawing.Size(158, 23);
            this.dodajoperatera.TabIndex = 2;
            this.dodajoperatera.Text = "DodajOperatera";
            this.dodajoperatera.UseVisualStyleBackColor = true;
            this.dodajoperatera.Click += new System.EventHandler(this.dodajoperatera_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dodajoperatera);
            this.Controls.Add(this.prikazivozilo);
            this.Controls.Add(this.prikazioperaterabtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button prikazioperaterabtn;
        private System.Windows.Forms.Button prikazivozilo;
        private System.Windows.Forms.Button dodajoperatera;
    }
}

