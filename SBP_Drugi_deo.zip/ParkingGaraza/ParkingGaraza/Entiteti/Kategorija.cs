﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Kategorija
    {
        public virtual int ID { get; set; }
        public virtual string Velicina_vozila { get; set; }
        public virtual ParkingMesto ID_Parking_mesta { get; set; }
    }
}
