﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Vozilo
    {
        public virtual int ID { get; set; }
        public virtual string Marka { get; set; }
        public virtual string Tip { get; set; }
        public virtual string Registarski_broj { get; set; }
        public virtual Vlasnik ID_Vlasnika { get; set; }
        public virtual Pojedinacna ID_Karte { get; set; }
    }
}
