﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Operater
    {
        public virtual int ID { get; set; }
        public virtual long JMBG { get; set; }
        public virtual string Ime { get; set; }
        public virtual string Prezime { get; set; }
        public virtual DateTime Datum_rodjenja { get; set; }
        public virtual DateTime Datum_zaposlenja { get; set; }
        public virtual int Radni_staz { get; set; }

        public virtual IList<RFIDKartica> KarteZaKontrolu { get; set; }

        public virtual IList<Smena> SmeneOperatera { get; set; }

        public Operater()
        {
            KarteZaKontrolu = new List<RFIDKartica>();
            SmeneOperatera = new List<Smena>();
        }
    }
}
