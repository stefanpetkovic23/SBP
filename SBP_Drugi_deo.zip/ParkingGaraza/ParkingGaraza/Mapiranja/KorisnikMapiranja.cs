﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class KorisnikMapiranja:SubclassMap<Korisnik>
    {
        public KorisnikMapiranja() {

            Table("KORISNIK");

            KeyColumn("ID");
            Map(x => x.JMBG, "JMBG");
            HasMany(x => x.ListaPretplatnih).KeyColumn("ID_KORISNIKA").Inverse().Cascade.All();
        }
    }
}
