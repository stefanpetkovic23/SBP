﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    class VlasnikMapiranja:SubclassMap<Vlasnik>
    {
        public VlasnikMapiranja() {

            Table("VLASNIK");
            KeyColumn("ID");
        }
    }
}
