﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using ParkingGaraza.Entiteti;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class RFIDKarticaMapiranja:ClassMap<RFIDKartica>
    {
        public RFIDKarticaMapiranja() {

            Table("RFID_KARTICA");
            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
        
            References(x => x.ID_Operatera).Column("ID_OPERATERA").LazyLoad();
        }
    }
}
