﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using ParkingGaraza.Entiteti;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class KategorijaMapiranja:ClassMap<Kategorija>
    {
        public KategorijaMapiranja() {

            Table("KATEGORIJA");
            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Velicina_vozila, "VELICINA_VOZILA");
            References(x => x.ID_Parking_mesta).Column("ID_PARKING_MESTA").LazyLoad();
        }
    }
}
