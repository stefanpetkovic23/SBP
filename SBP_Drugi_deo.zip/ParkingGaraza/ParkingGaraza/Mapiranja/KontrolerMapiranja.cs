﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ParkingGaraza.Entiteti;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class KontrolerMapiranja: SubclassMap<Kontroler>
    {
        public KontrolerMapiranja() {
            
            Table("KONTROLER");
            KeyColumn("ID");
            Map(x => x.Vreme_rada, "VREME_RADA");
            HasMany(x => x.SmeneKontrolera).KeyColumn("ID_KONTROLERA").Inverse().Cascade.All();
        }
        
    }
}
