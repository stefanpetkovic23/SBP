﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class VoziloMapiranja:ClassMap<Vozilo>
    {
        public VoziloMapiranja() {

            Table("VOZILO");
            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Marka, "MARKA");
            Map(x => x.Tip, "TIP");
            Map(x => x.Registarski_broj, "REGISTARSKI_BROJ");
            References(x => x.ID_Karte).Column("ID_KARTE").LazyLoad();
            References(x => x.ID_Vlasnika).Column("ID_VLASNIKA").LazyLoad();
        }
    }
}
