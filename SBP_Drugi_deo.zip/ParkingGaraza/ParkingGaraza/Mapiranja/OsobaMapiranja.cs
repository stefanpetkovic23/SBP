﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class OsobaMapiranja:ClassMap<Osoba>
    {
        public OsobaMapiranja() {

            Table("OSOBA");
            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Ime, "IME");
            Map(x => x.Prezime, "PREZIME");
        }
    }
}
