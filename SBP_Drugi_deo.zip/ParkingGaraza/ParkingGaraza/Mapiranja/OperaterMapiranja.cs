﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class OperaterMapiranja :ClassMap<Operater>
    {
        public OperaterMapiranja() {

            Table("OPERATER");

            Id(x => x.ID).Column("ID").GeneratedBy.TriggerIdentity();
            Map(x => x.JMBG, "JMBG");
            Map(x => x.Datum_rodjenja, "DATUM_RODJENJA");
            Map(x => x.Ime, "IME");
            Map(x => x.Prezime, "PREZIME");
            Map(x => x.Datum_zaposlenja, "DATUM_ZAPOSLENJA");
            Map(x => x.Radni_staz, "RADNI_STAZ");
            HasMany(x => x.KarteZaKontrolu).KeyColumn("ID_OPERATERA").Inverse().Cascade.All();
            HasMany(x => x.SmeneOperatera).KeyColumn("ID_OPERATERA").Inverse().Cascade.All();
        }
    }
}
