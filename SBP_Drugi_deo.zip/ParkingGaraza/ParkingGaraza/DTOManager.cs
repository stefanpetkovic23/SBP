﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using ParkingGaraza.Entiteti;
using System.Threading.Tasks;

namespace ParkingGaraza
{
    class DTOManager
    {
        public static List<ParkingMestoPregled> GetParkingMestoPregled()
        {
            List<ParkingMestoPregled> parkingmestoinfo = new List<ParkingMestoPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.ParkingMesto> parkingmesto = from p in s.Query<Entiteti.ParkingMesto>() select p;
                foreach (ParkingMesto p in parkingmesto)
                {
                    parkingmestoinfo.Add(new ParkingMestoPregled(p.ID, p.Sprat, p.Status));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }

            return parkingmestoinfo;
        }
        public static ParkingMestoBasic DodajParkingMesto(ParkingMestoBasic pm)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.ParkingMesto parkingMesto = new Entiteti.ParkingMesto();
                parkingMesto.Sprat = pm.Sprat;
                parkingMesto.Status = pm.Status;

                s.Save(parkingMesto);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }

            return pm;
        }
        public static void DeleteParkingMesto(int ID)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.ParkingMesto p = s.Load<Entiteti.ParkingMesto>(ID);

                s.Delete(p);
                s.Flush();

                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<ParkingMestoBasic> GetParkingMestoBasic()
        {
            List<ParkingMestoBasic> parkinginfo = new List<ParkingMestoBasic>();
            try
            {
                ISession s = DataLayer.GetSession();

                IEnumerable<Entiteti.ParkingMesto> parking = from p in s.Query<Entiteti.ParkingMesto>()where p.Status=="Slobodno" select p;

                foreach (Entiteti.ParkingMesto p in parking)
                {
                    parkinginfo.Add(new ParkingMestoBasic(p.ID, p.Sprat, p.Status));
                }

                s.Close();
            }
            catch (Exception ec)
            {
                
            }
            return parkinginfo;
        }
        public static List<OperaterPregled> GetOperateraPregled()
        {
            List<OperaterPregled> operaterinfo = new List<OperaterPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Operater> operaters = from p in s.Query<Entiteti.Operater>() select p;
                foreach (Operater p in operaters)
                {
                    operaterinfo.Add(new OperaterPregled(p.ID,p.JMBG,p.Ime,p.Prezime,p.Datum_rodjenja,p.Datum_zaposlenja,p.Radni_staz));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return operaterinfo;
        }
        public static OperaterBasic getOperater(int id)
        {
            OperaterBasic ob = new OperaterBasic();
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Operater op = s.Load<Entiteti.Operater>(id);
                ob = new OperaterBasic(op.ID, op.JMBG, op.Ime, op.Prezime, op.Datum_rodjenja, op.Datum_zaposlenja, op.Radni_staz);

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return ob;
        }
        public static void DodajOperatera( OperaterBasic op)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Operater operater = new Entiteti.Operater();
                operater.JMBG = op.JMBG;
                operater.Ime = op.Ime;
                operater.Prezime = op.Prezime;
                operater.Datum_rodjenja = op.Datum_rodjenja;
                operater.Datum_zaposlenja = op.Datum_zaposlenja;
                operater.Radni_staz = op.Radni_staz;

                s.Save(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static void DeleteOperatera(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Operater operater = s.Load<Entiteti.Operater>(id);

                s.Delete(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdateOperateraBasic(OperaterBasic ob)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Operater operater = s.Load<Entiteti.Operater>(ob.ID);
                operater.JMBG = ob.JMBG;
                operater.Ime = ob.Ime;
                operater.Prezime = ob.Prezime;
                operater.Datum_rodjenja = ob.Datum_rodjenja;
                operater.Datum_zaposlenja = ob.Datum_zaposlenja;
                operater.Radni_staz = ob.Radni_staz;

                s.Update(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<KontrolerBasic> GetKontrolera()
        {
            List<KontrolerBasic> kontrolerinfo = new List<KontrolerBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Kontroler> operaters = from p in s.Query<Entiteti.Kontroler>() select p;
                foreach (Kontroler p in operaters)
                {
                    kontrolerinfo.Add(new KontrolerBasic(p.ID, p.JMBG, p.Ime, p.Prezime, p.Datum_rodjenja, p.Datum_zaposlenja, p.Radni_staz,p.Vreme_rada));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return kontrolerinfo;
        }
        public static void DodajKontrolera(KontrolerBasic kon)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Kontroler kontroler = new Kontroler();
                kontroler.JMBG = kon.JMBG;
                kontroler.Ime = kon.Ime;
                kontroler.Prezime = kon.Prezime;
                kontroler.Datum_rodjenja = kon.Datum_rodjenja;
                kontroler.Datum_zaposlenja = kon.Datum_zaposlenja;
                kontroler.Vreme_rada = kon.Vreme_rada;

                s.SaveOrUpdate(kontroler);
                s.Flush();
                s.Close();

            }
            catch (Exception ec)
            {

            }
        }
        public static void DeleteKontrolera(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Kontroler kontroler = s.Load<Entiteti.Kontroler>(id);

                s.Delete(kontroler);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static List<VoziloBasic> GetVozila()
        {
            List<VoziloBasic> listavozilapregled = new List<VoziloBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Vozilo> listavozila = from p in s.Query<Entiteti.Vozilo>() select p;

                foreach (Vozilo v in listavozila)
                {
                    listavozilapregled.Add(new VoziloBasic(v.ID, v.Marka, v.Tip, v.Registarski_broj,v.ID_Vlasnika,v.ID_Karte));

                    s.Close();
                }
            }
            catch (Exception ec)
            {
                
            }
            return listavozilapregled;
        }
        public static void DodajVozilo(VoziloBasic vb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Vozilo vozilo = new Vozilo();
                vozilo.Marka = vb.Marka;
                vozilo.Tip = vb.Tip;
                vozilo.Registarski_broj = vb.Registarski_broj;
                vozilo.ID_Vlasnika = vb.ID_Vlasnika;
                vozilo.ID_Karte = vb.ID_Karte;

                s.Save(vozilo);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static void DeleteVozilo(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Vozilo vozilo = s.Load<Entiteti.Vozilo>(id);

                s.Delete(vozilo);
                s.Flush();
                s.Close();

            }
            catch (Exception ec)
            {

            }
        }
        public static OsobaBasic GetOsoba(int id)
        {
            OsobaBasic osoba = new OsobaBasic();
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Osoba o = s.Load<Entiteti.Osoba>(id);
                osoba = new OsobaBasic(o.ID, o.Ime, o.Prezime);

                s.Close();
            }
            catch (Exception ec)
            {

            }

            return osoba;
        }
        public static void DodajKorisnika(KorisnikBasic kb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Korisnik korisnik = new Korisnik();
                korisnik.Ime = kb.Ime;
                korisnik.Prezime = kb.Prezime;
                korisnik.JMBG = kb.JMBG;

                s.Save(korisnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec) 
            {

            }
        }
        public static int GetIDKorisnika(int jmbg)
        {
            int IDKorisnika = 0;
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Korisnik> korisnici = from o in s.Query<Entiteti.Korisnik>() where o.JMBG == jmbg select o;

                foreach(Korisnik k in korisnici)
                {
                    IDKorisnika = k.ID;
                }
            }
            catch (Exception ec)
            {

            }
            return IDKorisnika;
        }
        public static void DodajVlasnika(VlasnikBasic vb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Vlasnik vlasnik = new Vlasnik();
                vlasnik.Ime = vb.Ime;
                vlasnik.Prezime = vb.Prezime;

                s.Save(vlasnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static int GetIDVlasnika(int id)
        {
            int IDVlasnika = 0;
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Vlasnik> vlasnici = from o in s.Query<Entiteti.Vlasnik>() where o.ID == id select o;

                foreach (Vlasnik v in vlasnici)
                {
                    IDVlasnika = v.ID;
                }
            }
            catch (Exception ec)
            {
                
            }
            return IDVlasnika;
        }
        public static Pretplatna GetPretplatna(int id)
        {
            Pretplatna p = new Pretplatna();
            try
            {
                ISession s = DataLayer.GetSession();

                p = s.Load<Entiteti.Pretplatna>(id);

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return p;
        }
        public static void DodajPretplatnu(PretplatnaBasic pb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Pretplatna pretplatna = new Entiteti.Pretplatna();

                pretplatna.Rezervisano_mesto = pb.Rezervisano_mesto;
                pretplatna.Vreme_vazenja_parkinga = pb.Vreme_vazenja_karte;

                s.Save(pretplatna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeletePretplatnu(int id)
        {
            try 
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Pretplatna pretplatna = s.Load<Entiteti.Pretplatna>(id);

                s.Delete(pretplatna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<PretplatnaBasic> GetPretplatnaBasic()
        {
            List<PretplatnaBasic> pretplatnekarte = new List<PretplatnaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Pretplatna> karta = from k in s.Query<Entiteti.Pretplatna>() select k;

                foreach (Pretplatna p in karta)
                {
                    pretplatnekarte.Add(new PretplatnaBasic(p.ID, p.ID_Operatera, p.Rezervisano_mesto, p.Vreme_vazenja_parkinga, p.ID_Korisnika));
                }
                s.Close();
            }
            catch (Exception ec)
            {

            }
            return pretplatnekarte;
        }
        public static Pojedinacna GetPojedinacna(int id)
        {
            Pojedinacna p = new Pojedinacna();
            try 
            {
                ISession s = DataLayer.GetSession();

                p = s.Load<Entiteti.Pojedinacna>(id);

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return p;
        }
        public static void DodajPojedinacnu(PojedinacnaBasic pb)
        {
            try 
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Pojedinacna pojedinacna = new Entiteti.Pojedinacna();
                pojedinacna.Registarska_oznaka_vozila = pb.Registarska_oznaka_vozila;
                pojedinacna.Vreme_izdavanja = pb.Vreme_izdavanja;
                pojedinacna.Vreme_izlaska = pb.Vreme_izlaska;

                s.Save(pojedinacna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeletePojedinacnu(int id)
        {
            try 
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Pojedinacna pojedinacna = s.Load<Entiteti.Pojedinacna>(id);

                s.Delete(pojedinacna);
                s.Flush();
                s.Close();
            }
            catch 
            { }
        }
        public static List<PojedinacnaBasic> GetPojedinacnaBasic()
        {
            List<PojedinacnaBasic> pojedinacnekarte = new List<PojedinacnaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Pojedinacna> karta = from k in s.Query<Entiteti.Pojedinacna>() select k;

                foreach (Pojedinacna p in karta)
                {
                    pojedinacnekarte.Add(new PojedinacnaBasic(p.ID, p.ID_Operatera, p.Registarska_oznaka_vozila, p.Vreme_izdavanja, p.Vreme_izlaska, p.ID_parking_mesta));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return pojedinacnekarte;
        }
        public static List<KategorijaBasic> GetKategorija()
        {
            List<KategorijaBasic> kategorije = new List<KategorijaBasic>();

            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Kategorija> kategorija = from k in s.Query<Entiteti.Kategorija>() select k;

                foreach (Entiteti.Kategorija k in kategorija)
                {
                    kategorije.Add(new KategorijaBasic(k.ID, k.Velicina_vozila, k.ID_Parking_mesta));
                }
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
            return kategorije;
        }
        public static void DodajKategoriju(KategorijaBasic kb)
        {
            Kategorija kategorija = new Kategorija();
            try
            {
                ISession s = DataLayer.GetSession();
                kategorija.Velicina_vozila = kb.Velicina_vozila;
                kategorija.ID_Parking_mesta = s.Load<Entiteti.ParkingMesto>(kb.ID_Parking_mesta.ID);

                s.SaveOrUpdate(kategorija);
                s.Flush();
                s.Close();
            }
            catch (Exception ec) 
            {

            }
        }
        public static bool DaLiJePretplatna(int id)
        {
            bool t = true;
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.Pretplatna pretplatna = s.Load<Entiteti.Pretplatna>(id);

                s.Close();
            }
            catch (Exception ec)
            {
                t = false;
            }
            return t;
        }
        public static bool DaLiJeSlobodnoParkingmesto(int id)
        {
            bool t = true;
            try
            {
                ISession s = DataLayer.GetSession();
                Entiteti.ParkingMesto parkingmesto = s.Load<Entiteti.ParkingMesto>(id);
                if (parkingmesto.Status == "Slobodno")
                {
                    t = true;
                }
                else
                    t = false;
            }
            catch (Exception ec)
            { 

            }
            return t;
        }
        public static List<SmenaBasic> GetSmena()
        {
            List<SmenaBasic> smene = new List<SmenaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Entiteti.Smena> smena = from k in s.Query<Entiteti.Smena>() select k;

                foreach (Entiteti.Smena sm in smena)
                {
                    smene.Add(new SmenaBasic(sm.ID, sm.Pocetak_smene, sm.Kraj_smene, sm.ID_Operatera, sm.ID_Kontrolera));
                }

                s.Close();
            }
            catch (Exception)
            {

            }

            return smene;
        }
    }

    
}
