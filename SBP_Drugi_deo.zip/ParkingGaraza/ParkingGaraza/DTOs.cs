﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ParkingGaraza.Entiteti;
using System.Threading.Tasks;

namespace ParkingGaraza
{
    public class KategorijaPregled
    {
        public int ID { get; set; }
        public string Velicina_vozila { get; set; }
        public KategorijaPregled(int id, string velicina)
        {
            this.ID = id;
            this.Velicina_vozila = velicina;
        }
        public KategorijaPregled() { }
    }
    public class KategorijaBasic
    {
        public virtual int ID { get; set; }
        public virtual string Velicina_vozila { get; set; }
        public virtual ParkingMesto ID_Parking_mesta { get; set; }
        public KategorijaBasic(int id, string velicina, ParkingMesto pm)
        {
            this.ID = id;
            this.Velicina_vozila = velicina;
            this.ID_Parking_mesta = pm;
        }
        public KategorijaBasic() { }
    }
    public class OperaterBasic
    {
        public virtual  int ID {get;set;}
        public virtual long JMBG { get; set; }
        public virtual string Ime { get; set; }
        public virtual string Prezime { get; set; }
        public virtual DateTime Datum_rodjenja { get; set; }
        public virtual DateTime Datum_zaposlenja { get; set; }
        public virtual int Radni_staz { get; set; }
        public OperaterBasic(int id,long jmbg,string ime,string prezime,DateTime datumrodjenja,DateTime datumzaposlenja,int radnistaz) 
        {
            this.ID = id;
            this.JMBG = jmbg;
            this.Ime = ime;
            this.Prezime = prezime;
            this.Datum_rodjenja = datumrodjenja;
            this.Datum_zaposlenja = datumzaposlenja;
            this.Radni_staz = radnistaz;
        }
        public OperaterBasic() { }
    }
    public class OperaterPregled
    {
        public virtual int ID { get; set; }
        public virtual long JMBG { get; set; }
        public virtual string Ime { get; set; }
        public virtual string Prezime { get; set; }
        public virtual DateTime Datum_rodjenja { get; set; }
        public virtual DateTime Datum_zaposlenja { get; set; }
        public virtual int Radni_staz { get; set; }
        public OperaterPregled(int id,long jmbg, string ime, string prezime, DateTime datumrodjenja, DateTime datumzaposlenja, int radnistaz)
        {
            this.ID = id;
            this.JMBG = jmbg;
            this.Ime = ime;
            this.Prezime = prezime;
            this.Datum_rodjenja = datumrodjenja;
            this.Datum_zaposlenja = datumzaposlenja;
            this.Radni_staz = radnistaz;
        }
        public OperaterPregled() { }
    }
    public class KontrolerBasic : OperaterBasic
    {
        public virtual int Vreme_rada { get; set; }
        public KontrolerBasic(int id,long jmbg,string ime,string prezime,DateTime datumrodjenja,DateTime datumzaposlenja,int radnistaz,int vremerada)
            :base(id,jmbg,ime,prezime,datumrodjenja,datumzaposlenja,radnistaz)
        {
            this.Vreme_rada = vremerada;
        }
        public KontrolerBasic() { }
    }
    public class OsobaBasic
    {
        public virtual int ID { get; set; }
        public virtual string Ime { get; set; }
        public virtual string Prezime { get; set; }
        public OsobaBasic(int id,string ime,string prezime)
        {
            this.ID = id;
            this.Ime = ime;
            this.Prezime = prezime;
        }
        public OsobaBasic() { }
    }
    public class KorisnikBasic:OsobaBasic
    {
        public virtual long JMBG { get; set; }
        public KorisnikBasic(int id,string ime,string prezime,long jmbg):base(id,ime,prezime)
        {
            this.JMBG = jmbg;
        }
        public KorisnikBasic() { }
    }
    public class VlasnikBasic : OsobaBasic
    {
        public VlasnikBasic(int id, string ime, string prezime) : base(id, ime, prezime)
        {
            
        }
        public VlasnikBasic() { }
    }
    public class ParkingMestoPregled
    {
        public virtual int ID { get; set; }

        public virtual int Sprat { get; set; }

        public virtual string Status { get; set; }
        public ParkingMestoPregled(int id,int sprat,string status)
        {
            this.ID = id;
            this.Sprat = sprat;
            this.Status = status;
        }
        public ParkingMestoPregled() { }
    }
    public class ParkingMestoBasic
    {
        public virtual int Id { get; set; }
        public virtual int Sprat { get; set; }
        public virtual string Status { get; set; }
        public virtual IList<Kategorija> Kategorije { get; set; }
        public ParkingMestoBasic(int id, int sprat, string status)
        {
            this.Id = id;
            this.Sprat = sprat;
            this.Status = status;
        }
        public ParkingMestoBasic() { Kategorije = new List<Kategorija>(); }
    }
    public class RFIDKarticaBasic
    {
        public virtual int ID { get; set; }
        public virtual Operater ID_Operatera { get; set; }
        public RFIDKarticaBasic(int id, Operater idoperatera)
        {
            this.ID = id;
            this.ID_Operatera = idoperatera;
        }
        public RFIDKarticaBasic() { }
    }
    public class PojedinacnaBasic : RFIDKarticaBasic
    {
        public virtual string Registarska_oznaka_vozila { get; set; }
        public virtual DateTime Vreme_izdavanja { get; set; }
        public virtual DateTime Vreme_izlaska { get; set; }
        public virtual ParkingMesto ID_parking_mesta { get; set; }
        public PojedinacnaBasic(int id,Operater idop,string regoznaka,DateTime vremeizdavanja,DateTime vremeizlaska,ParkingMesto idparkingmesta)
            :base(id,idop)
        {
            this.Registarska_oznaka_vozila = regoznaka;
            this.Vreme_izdavanja = vremeizdavanja;
            this.Vreme_izlaska = vremeizlaska;
            this.ID_parking_mesta = idparkingmesta;
        }
        public PojedinacnaBasic() { }
    }
    public class PretplatnaBasic : RFIDKarticaBasic
    {
        public virtual string Rezervisano_mesto { get; set; }
        public virtual int Vreme_vazenja_karte { get; set; }
        public virtual Korisnik ID_Korisnika { get; set; }
        public PretplatnaBasic(int id,Operater idoperatera,string rezervisano,int vremevazenja,Korisnik idkorisnika):base(id,idoperatera)
        {
            this.Rezervisano_mesto = rezervisano;
            this.Vreme_vazenja_karte = vremevazenja;
            this.ID_Korisnika = idkorisnika;
        }
        public PretplatnaBasic() { }
    }
    public class SmenaBasic
    {
        public virtual int ID { get; set; }
        public virtual int Pocetak_smene { get; set; }
        public virtual int Kraj_smene { get; set; }
        public virtual Operater ID_Operatera { get; set; }
        public virtual Kontroler ID_Kontrolera { get; set; }
        public SmenaBasic(int id,int pocetaksmene,int krajsmene,Operater idop,Kontroler idkont)
        {
            this.ID = id;
            this.Pocetak_smene = pocetaksmene;
            this.Kraj_smene = krajsmene;
            this.ID_Operatera = idop;
            this.ID_Kontrolera = idkont;
        }
        public SmenaBasic() { }
    }
    public class VoziloBasic
    {
        public virtual int ID { get; set; }
        public virtual string Marka { get; set; }
        public virtual string Tip { get; set; }
        public virtual string Registarski_broj { get; set; }
        public virtual Vlasnik ID_Vlasnika { get; set; }
        public virtual Pojedinacna ID_Karte { get; set; }
        public VoziloBasic(int id,string marka,string tip,string registracija,Vlasnik idvlasnika,Pojedinacna idkarte)
        {
            this.ID = id;
            this.Marka = marka;
            this.Tip = tip;
            this.Registarski_broj = registracija;
            this.ID_Vlasnika = idvlasnika;
            this.ID_Karte = idkarte;
        }
        public VoziloBasic() { }
    }
    public class VoziloPregled
    {
        public virtual int ID { get; set; }
        public virtual string Marka { get; set; }
        public virtual string Tip { get; set; }
        public virtual string Registarski_broj { get; set; }
        public VoziloPregled(int id, string marka, string tip, string registracija)
        {
            this.ID = id;
            this.Marka = marka;
            this.Tip = tip;
            this.Registarski_broj = registracija;
        }
        public VoziloPregled() { }
    }
   
}
