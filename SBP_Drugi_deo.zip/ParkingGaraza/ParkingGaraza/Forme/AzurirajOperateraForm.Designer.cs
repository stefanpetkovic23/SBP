﻿
namespace ParkingGaraza.Forme
{
    partial class AzurirajOperateraForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.azurirajBTN = new System.Windows.Forms.Button();
            this.radnistazTXB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.jmbgTBX = new System.Windows.Forms.TextBox();
            this.prezimeTXB = new System.Windows.Forms.TextBox();
            this.imeTXB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.datumrodjenjadt = new System.Windows.Forms.DateTimePicker();
            this.datumzaposlenjadt = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.datumzaposlenjadt);
            this.groupBox1.Controls.Add(this.datumrodjenjadt);
            this.groupBox1.Controls.Add(this.azurirajBTN);
            this.groupBox1.Controls.Add(this.radnistazTXB);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.jmbgTBX);
            this.groupBox1.Controls.Add(this.prezimeTXB);
            this.groupBox1.Controls.Add(this.imeTXB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(775, 425);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Podaci o operateru";
            // 
            // azurirajBTN
            // 
            this.azurirajBTN.Location = new System.Drawing.Point(606, 342);
            this.azurirajBTN.Name = "azurirajBTN";
            this.azurirajBTN.Size = new System.Drawing.Size(154, 65);
            this.azurirajBTN.TabIndex = 12;
            this.azurirajBTN.Text = "AŽURIRAJ OPERATERA";
            this.azurirajBTN.UseVisualStyleBackColor = true;
            this.azurirajBTN.Click += new System.EventHandler(this.azurirajBTN_Click);
            // 
            // radnistazTXB
            // 
            this.radnistazTXB.Location = new System.Drawing.Point(574, 145);
            this.radnistazTXB.Name = "radnistazTXB";
            this.radnistazTXB.Size = new System.Drawing.Size(186, 26);
            this.radnistazTXB.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(402, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Radni staž:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(398, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Datum zaposlenja:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(398, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Datum rođenja:";
            // 
            // jmbgTBX
            // 
            this.jmbgTBX.Location = new System.Drawing.Point(105, 148);
            this.jmbgTBX.Name = "jmbgTBX";
            this.jmbgTBX.Size = new System.Drawing.Size(186, 26);
            this.jmbgTBX.TabIndex = 5;
            // 
            // prezimeTXB
            // 
            this.prezimeTXB.Location = new System.Drawing.Point(105, 98);
            this.prezimeTXB.Name = "prezimeTXB";
            this.prezimeTXB.Size = new System.Drawing.Size(186, 26);
            this.prezimeTXB.TabIndex = 4;
            // 
            // imeTXB
            // 
            this.imeTXB.Location = new System.Drawing.Point(105, 53);
            this.imeTXB.Name = "imeTXB";
            this.imeTXB.Size = new System.Drawing.Size(186, 26);
            this.imeTXB.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "JMBG:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime:";
            // 
            // datumrodjenjadt
            // 
            this.datumrodjenjadt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datumrodjenjadt.Location = new System.Drawing.Point(574, 53);
            this.datumrodjenjadt.Name = "datumrodjenjadt";
            this.datumrodjenjadt.Size = new System.Drawing.Size(186, 26);
            this.datumrodjenjadt.TabIndex = 13;
            // 
            // datumzaposlenjadt
            // 
            this.datumzaposlenjadt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datumzaposlenjadt.Location = new System.Drawing.Point(574, 101);
            this.datumzaposlenjadt.Name = "datumzaposlenjadt";
            this.datumzaposlenjadt.Size = new System.Drawing.Size(186, 26);
            this.datumzaposlenjadt.TabIndex = 14;
            // 
            // AzurirajOperateraForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "AzurirajOperateraForm";
            this.Text = "AzurirajOperateraForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox jmbgTBX;
        private System.Windows.Forms.TextBox prezimeTXB;
        private System.Windows.Forms.TextBox imeTXB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button azurirajBTN;
        private System.Windows.Forms.TextBox radnistazTXB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker datumzaposlenjadt;
        private System.Windows.Forms.DateTimePicker datumrodjenjadt;
    }
}