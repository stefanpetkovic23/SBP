﻿
namespace ParkingGaraza.Forme
{
    partial class OperateriForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.operaterilist = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.obrisioperateraBTN = new System.Windows.Forms.Button();
            this.azurirajoperateraBTN = new System.Windows.Forms.Button();
            this.kontrolaBTN = new System.Windows.Forms.Button();
            this.postavikontroleraBTN = new System.Windows.Forms.Button();
            this.smeneBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // operaterilist
            // 
            this.operaterilist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.operaterilist.FullRowSelect = true;
            this.operaterilist.GridLines = true;
            this.operaterilist.HideSelection = false;
            this.operaterilist.Location = new System.Drawing.Point(12, 68);
            this.operaterilist.Name = "operaterilist";
            this.operaterilist.Size = new System.Drawing.Size(521, 351);
            this.operaterilist.TabIndex = 0;
            this.operaterilist.UseCompatibleStateImageBehavior = false;
            this.operaterilist.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Datum rođenja";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "JMBG";
            this.columnHeader3.Width = 50;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Ime";
            this.columnHeader4.Width = 40;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Prezime";
            this.columnHeader5.Width = 70;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Datum zaposlenja";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Radni staž";
            this.columnHeader7.Width = 80;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "LISTA OPERATERA";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(575, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(199, 54);
            this.button1.TabIndex = 2;
            this.button1.Text = "Dodaj Operatera";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // obrisioperateraBTN
            // 
            this.obrisioperateraBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.obrisioperateraBTN.Location = new System.Drawing.Point(575, 131);
            this.obrisioperateraBTN.Name = "obrisioperateraBTN";
            this.obrisioperateraBTN.Size = new System.Drawing.Size(199, 54);
            this.obrisioperateraBTN.TabIndex = 3;
            this.obrisioperateraBTN.Text = "Obriši Operatera";
            this.obrisioperateraBTN.UseVisualStyleBackColor = true;
            this.obrisioperateraBTN.Click += new System.EventHandler(this.obrisioperateraBTN_Click);
            // 
            // azurirajoperateraBTN
            // 
            this.azurirajoperateraBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.azurirajoperateraBTN.Location = new System.Drawing.Point(575, 191);
            this.azurirajoperateraBTN.Name = "azurirajoperateraBTN";
            this.azurirajoperateraBTN.Size = new System.Drawing.Size(199, 54);
            this.azurirajoperateraBTN.TabIndex = 4;
            this.azurirajoperateraBTN.Text = "Ažuriraj Operatera";
            this.azurirajoperateraBTN.UseVisualStyleBackColor = true;
            this.azurirajoperateraBTN.Click += new System.EventHandler(this.azurirajoperateraBTN_Click);
            // 
            // kontrolaBTN
            // 
            this.kontrolaBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.kontrolaBTN.Location = new System.Drawing.Point(575, 251);
            this.kontrolaBTN.Name = "kontrolaBTN";
            this.kontrolaBTN.Size = new System.Drawing.Size(199, 54);
            this.kontrolaBTN.TabIndex = 5;
            this.kontrolaBTN.Text = "Kontrola Karata";
            this.kontrolaBTN.UseVisualStyleBackColor = true;
            this.kontrolaBTN.Click += new System.EventHandler(this.kontrolaBTN_Click);
            // 
            // postavikontroleraBTN
            // 
            this.postavikontroleraBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.postavikontroleraBTN.Location = new System.Drawing.Point(575, 311);
            this.postavikontroleraBTN.Name = "postavikontroleraBTN";
            this.postavikontroleraBTN.Size = new System.Drawing.Size(199, 67);
            this.postavikontroleraBTN.TabIndex = 6;
            this.postavikontroleraBTN.Text = "Postavi za Kontrolera";
            this.postavikontroleraBTN.UseVisualStyleBackColor = true;
            this.postavikontroleraBTN.Click += new System.EventHandler(this.postavikontroleraBTN_Click);
            // 
            // smeneBTN
            // 
            this.smeneBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.smeneBTN.Location = new System.Drawing.Point(575, 384);
            this.smeneBTN.Name = "smeneBTN";
            this.smeneBTN.Size = new System.Drawing.Size(199, 54);
            this.smeneBTN.TabIndex = 7;
            this.smeneBTN.Text = "Smene";
            this.smeneBTN.UseVisualStyleBackColor = true;
            this.smeneBTN.Click += new System.EventHandler(this.smeneBTN_Click);
            // 
            // OperateriForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.smeneBTN);
            this.Controls.Add(this.postavikontroleraBTN);
            this.Controls.Add(this.kontrolaBTN);
            this.Controls.Add(this.azurirajoperateraBTN);
            this.Controls.Add(this.obrisioperateraBTN);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.operaterilist);
            this.Name = "OperateriForm";
            this.Text = "OperateriForm";
            this.Load += new System.EventHandler(this.OperateriForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView operaterilist;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button obrisioperateraBTN;
        private System.Windows.Forms.Button azurirajoperateraBTN;
        private System.Windows.Forms.Button kontrolaBTN;
        private System.Windows.Forms.Button postavikontroleraBTN;
        private System.Windows.Forms.Button smeneBTN;
    }
}