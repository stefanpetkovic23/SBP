﻿
namespace ParkingGaraza.Forme
{
    partial class RegistrovanjeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.imeTXB = new System.Windows.Forms.TextBox();
            this.prezimeTXB = new System.Windows.Forms.TextBox();
            this.jmbgTXB = new System.Windows.Forms.TextBox();
            this.registracijaBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(440, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Unesite svoje podatke u sledeća polja";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(296, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(257, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prezime:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(272, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "JMBG:";
            // 
            // imeTXB
            // 
            this.imeTXB.Location = new System.Drawing.Point(352, 93);
            this.imeTXB.Name = "imeTXB";
            this.imeTXB.Size = new System.Drawing.Size(157, 22);
            this.imeTXB.TabIndex = 4;
            // 
            // prezimeTXB
            // 
            this.prezimeTXB.Location = new System.Drawing.Point(352, 171);
            this.prezimeTXB.Name = "prezimeTXB";
            this.prezimeTXB.Size = new System.Drawing.Size(157, 22);
            this.prezimeTXB.TabIndex = 5;
            // 
            // jmbgTXB
            // 
            this.jmbgTXB.Location = new System.Drawing.Point(352, 248);
            this.jmbgTXB.Name = "jmbgTXB";
            this.jmbgTXB.Size = new System.Drawing.Size(157, 22);
            this.jmbgTXB.TabIndex = 6;
            // 
            // registracijaBTN
            // 
            this.registracijaBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.registracijaBTN.Location = new System.Drawing.Point(241, 341);
            this.registracijaBTN.Name = "registracijaBTN";
            this.registracijaBTN.Size = new System.Drawing.Size(312, 78);
            this.registracijaBTN.TabIndex = 7;
            this.registracijaBTN.Text = "REGISTRUJ SE";
            this.registracijaBTN.UseVisualStyleBackColor = true;
            this.registracijaBTN.Click += new System.EventHandler(this.registracijaBTN_Click);
            // 
            // RegistrovanjeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.registracijaBTN);
            this.Controls.Add(this.jmbgTXB);
            this.Controls.Add(this.prezimeTXB);
            this.Controls.Add(this.imeTXB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RegistrovanjeForm";
            this.Text = "RegistrovanjeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox imeTXB;
        private System.Windows.Forms.TextBox prezimeTXB;
        private System.Windows.Forms.TextBox jmbgTXB;
        private System.Windows.Forms.Button registracijaBTN;
    }
}