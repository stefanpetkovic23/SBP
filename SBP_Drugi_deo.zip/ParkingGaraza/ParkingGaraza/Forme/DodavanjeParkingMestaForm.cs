﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class DodavanjeParkingMestaForm : Form
    {
        public DodavanjeParkingMestaForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ParkingMestoBasic parkingmesto = new ParkingMestoBasic();
            parkingmesto.Sprat = Int32.Parse(spratTXB.Text);
            parkingmesto.Status = statusTXB.Text;

            DTOManager.DodajParkingMesto(parkingmesto);
            MessageBox.Show("Uspešno ste dodali parking mesto!");
        }
    }
}
