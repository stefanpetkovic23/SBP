﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class SmeneForm : Form
    {
        public SmeneForm()
        {
            InitializeComponent();
        }
        private void SmeneForm_Load()
        {
        }
        public void popuniPodacima()
        {
            listasmena.Items.Clear();
            List<SmenaBasic> podaci = DTOManager.GetSmena();

            foreach (SmenaBasic sb in podaci)
            {
                ListViewItem item = new ListViewItem(new string[] { sb.ID.ToString(), sb.Pocetak_smene.ToString(), sb.Kraj_smene.ToString()});
                listasmena.Items.Add(item);
            }
            listasmena.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.popuniPodacima();
        }
    }
}
