﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class DodajOPForm : Form
    {
        public DodajOPForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OperaterBasic operater = new OperaterBasic();
            operater.Ime = txtboxime.Text;
            operater.Prezime = txtboxprezime.Text;
            operater.JMBG = Int64.Parse(txtboxjmbg.Text);
            operater.Datum_rodjenja = datimrodjenjadt.Value;
            operater.Datum_zaposlenja = datumzaposlenjadt.Value;
            operater.Radni_staz = Int32.Parse(txtradnistaz.Text);

            DTOManager.DodajOperatera(operater);
            MessageBox.Show("Uspešno ste dodali operatera!");
        }
    }
}
