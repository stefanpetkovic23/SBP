﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class KarteForm : Form
    {
        public KarteForm()
        {
            InitializeComponent();
        }
        private void KarteForm_Load(object sender, EventArgs e)
        {
            listView1.HideSelection = false;
            listView2.HideSelection = false;
            Prikazi();
        }
        public void Prikazi()
        {
            listView1.Items.Clear();
            listView2.Items.Clear();

            List<PojedinacnaBasic> listapojedinacnih = DTOManager.GetPojedinacnaBasic();
            foreach (PojedinacnaBasic pb in listapojedinacnih)
            {
                listView1.Items.Add(new ListViewItem(new string[] { pb.ID.ToString(), pb.Registarska_oznaka_vozila, pb.Vreme_izdavanja.ToString(), pb.Vreme_izlaska.ToString()}));
            }

            List<PretplatnaBasic> listapretplatnih = DTOManager.GetPretplatnaBasic();
            foreach (PretplatnaBasic pb in listapretplatnih)
            {
                listView2.Items.Add(new ListViewItem(new string[] { pb.ID.ToString(), pb.Rezervisano_mesto, pb.Vreme_vazenja_karte.ToString()}));
            }

            listView1.Refresh();
            listView2.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            this.Prikazi();
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite kartu koju želite da obrišete!");
                return;
            }
            int pojedinacnaID = Int32.Parse(listView1.SelectedItems[0].SubItems[0].Text);
            DTOManager.DeletePojedinacnu(pojedinacnaID);

            this.Prikazi();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite kartu koju želite da obrišete!");
                return;
            }
            int pretplatnaID = Int32.Parse(listView2.SelectedItems[0].SubItems[0].Text);
            DTOManager.DeletePretplatnu(pretplatnaID);

            this.Prikazi();
        }
    }
}
