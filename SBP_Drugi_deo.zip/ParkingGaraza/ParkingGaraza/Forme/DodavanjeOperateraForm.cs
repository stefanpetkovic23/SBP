﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class DodavanjeOperateraForm : Form
    {
        KontrolerBasic kontroler;
        OperaterBasic operater;
        public DodavanjeOperateraForm()
        {
            InitializeComponent();
        }
        public DodavanjeOperateraForm(OperaterBasic kb)
        {
            InitializeComponent();
            operater = kb;
            popuniPodacima();
        }
        public void popuniPodacima()
        {
            txtboxime.Text = operater.Ime;
            txtboxprezime.Text = operater.Prezime;
            txtboxjmbg.Text = operater.JMBG.ToString();
            datumrodjenjadt.Value = operater.Datum_rodjenja;
            datumzaposlenjadt.Value = operater.Datum_zaposlenja;
            txtboxradnistaz.Text = operater.Radni_staz.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //OperaterBasic op = DTOManager.getOperater(operater.ID);
            KontrolerBasic kontroler=dodajkontrolera();
            //kontroler.ID = op.ID;
            

            DTOManager.DodajKontrolera(kontroler);
            MessageBox.Show("Uspešno se dodali kontrolera!");
        }
        private KontrolerBasic dodajkontrolera()
        {
            KontrolerBasic kontroler = new KontrolerBasic();
            kontroler.ID = operater.ID;
            kontroler.Ime = txtboxime.Text;
            kontroler.Prezime = txtboxprezime.Text;
            kontroler.JMBG = Int64.Parse(txtboxjmbg.Text);
            kontroler.Datum_rodjenja = datumrodjenjadt.Value;
            kontroler.Datum_zaposlenja = datumzaposlenjadt.Value;
            kontroler.Radni_staz = Int32.Parse(txtboxradnistaz.Text);
            kontroler.Vreme_rada = Int32.Parse(txtboxvremerada.Text);

            return kontroler;
        }
        
    }
}
