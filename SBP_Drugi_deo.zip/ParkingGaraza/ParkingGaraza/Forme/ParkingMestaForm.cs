﻿using System;
using ParkingGaraza.Forme;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class ParkingMestaForm : Form
    {
        public ParkingMestaForm()
        {
            InitializeComponent();
        }

        public void Init()
        {
            listaparkingmesta.Items.Clear();

            List<ParkingMestoPregled> parkingInfos = DTOManager.GetParkingMestoPregled();
            foreach (ParkingMestoPregled pm in parkingInfos)
            {
                ListViewItem item = new ListViewItem(new string[] { pm.ID.ToString(), pm.Sprat.ToString(), pm.Status });
                listaparkingmesta.Items.Add(item);
            }
            listaparkingmesta.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DodavanjeParkingMestaForm formadodajparkingmesto = new DodavanjeParkingMestaForm();
            formadodajparkingmesto.ShowDialog();
            this.Init();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listaparkingmesta.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite parking mesto koje želite da obrišete!");
                    return;
            }
            int parkingmestoID = Int32.Parse(listaparkingmesta.SelectedItems[0].SubItems[0].Text);
            DTOManager.DeleteParkingMesto(parkingmestoID);

            this.Init();
        }

        private void vozilanaparkinguBTN_Click(object sender, EventArgs e)
        {
            VozilaForm forma = new VozilaForm();
            forma.ShowDialog();

        }

        private void kategorijeBTN_Click(object sender, EventArgs e)
        {
            KategorijeForm forma = new KategorijeForm();
            forma.ShowDialog();
        }

        private void ParkingMestaForm_Load(object sender, EventArgs e)
        {
            Init();
        }
    }
}
