﻿
namespace ParkingGaraza.Forme
{
    partial class VozilaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listaVozila = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dodajvoziloBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(152, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(474, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "VOZILA U PARKING GARAŽI";
            // 
            // listaVozila
            // 
            this.listaVozila.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listaVozila.FullRowSelect = true;
            this.listaVozila.GridLines = true;
            this.listaVozila.HideSelection = false;
            this.listaVozila.Location = new System.Drawing.Point(13, 72);
            this.listaVozila.Name = "listaVozila";
            this.listaVozila.Size = new System.Drawing.Size(531, 328);
            this.listaVozila.TabIndex = 1;
            this.listaVozila.UseCompatibleStateImageBehavior = false;
            this.listaVozila.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Marka";
            this.columnHeader2.Width = 145;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tip";
            this.columnHeader3.Width = 116;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Registarski broj";
            this.columnHeader4.Width = 222;
            // 
            // dodajvoziloBTN
            // 
            this.dodajvoziloBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dodajvoziloBTN.Location = new System.Drawing.Point(585, 195);
            this.dodajvoziloBTN.Name = "dodajvoziloBTN";
            this.dodajvoziloBTN.Size = new System.Drawing.Size(186, 48);
            this.dodajvoziloBTN.TabIndex = 2;
            this.dodajvoziloBTN.Text = "Prikaži Vozila";
            this.dodajvoziloBTN.UseVisualStyleBackColor = true;
            this.dodajvoziloBTN.Click += new System.EventHandler(this.dodajvoziloBTN_Click);
            // 
            // VozilaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dodajvoziloBTN);
            this.Controls.Add(this.listaVozila);
            this.Controls.Add(this.label1);
            this.Name = "VozilaForm";
            this.Text = "VozilaForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listaVozila;
        private System.Windows.Forms.Button dodajvoziloBTN;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}