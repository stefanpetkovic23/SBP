﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class OperateriForm : Form
    {
        public OperateriForm()
        {
            InitializeComponent();
        }

        public void popuniPodacima()
        {
            operaterilist.Items.Clear();
            List<OperaterPregled> podaci = DTOManager.GetOperateraPregled();

            foreach (OperaterPregled p in podaci)
            {
                ListViewItem item = new ListViewItem(new string[] { p.ID.ToString(), p.Datum_rodjenja.ToString(), p.JMBG.ToString(), p.Ime, p.Prezime, p.Datum_zaposlenja.ToString(), p.Radni_staz.ToString() });
                operaterilist.Items.Add(item);
            }

            operaterilist.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DodajOPForm formadodajoperatera = new DodajOPForm();
            formadodajoperatera.ShowDialog();
            this.popuniPodacima();
        }

        private void obrisioperateraBTN_Click(object sender, EventArgs e)
        {
            if (operaterilist.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite operatera kog želite da obrišete");
                return;
            }
            int operaterID = Int32.Parse(operaterilist.SelectedItems[0].SubItems[0].Text);
            DTOManager.DeleteOperatera(operaterID);

            this.popuniPodacima();
        }

        private void azurirajoperateraBTN_Click(object sender, EventArgs e)
        {
            if (operaterilist.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite operatera kog želite da izmenite");
                    return;
            }

            int operaterID =Int32.Parse(operaterilist.SelectedItems[0].SubItems[0].Text);
            OperaterBasic ob = DTOManager.getOperater(operaterID);
          
            AzurirajOperateraForm forma = new AzurirajOperateraForm(ob);
            forma.ShowDialog();
            this.popuniPodacima();
        }

        private void kontrolaBTN_Click(object sender, EventArgs e)
        {
            KarteForm forma = new KarteForm();
            forma.ShowDialog();
        }

        private void postavikontroleraBTN_Click(object sender, EventArgs e)
        {

            if (operaterilist.SelectedItems.Count == 0)
            {
                MessageBox.Show("Izaberite operatera kog želite da postavite za kontrolera!");
                return;
            }

            int operaterID = Int32.Parse(operaterilist.SelectedItems[0].SubItems[0].Text);
            OperaterBasic ob = DTOManager.getOperater(operaterID);
            KontrolerBasic kb = ob as KontrolerBasic;
            DodavanjeOperateraForm forma = new DodavanjeOperateraForm(ob);
            forma.ShowDialog();
        }

        private void smeneBTN_Click(object sender, EventArgs e)
        {
            SmeneForm forma = new SmeneForm();
            forma.ShowDialog();
        }

        private void OperateriForm_Load(object sender, EventArgs e)
        {
            popuniPodacima();
        }
    }
}
