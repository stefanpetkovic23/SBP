﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class VozilaForm : Form
    {
        public VozilaForm()
        {
            InitializeComponent();
        }
        private void VozilaForm_Load(object sender, EventArgs e)
        {
        }
        public void popuniPodacima()
        {
            listaVozila.Items.Clear();
            List<VoziloBasic> podaci = DTOManager.GetVozila();

            foreach (VoziloBasic vp in podaci)
            {
                ListViewItem item = new ListViewItem(new string[] { vp.ID.ToString(), vp.Marka, vp.Tip, vp.Registarski_broj });
                listaVozila.Items.Add(item);
            }
            listaVozila.Refresh();
        }

        private void dodajvoziloBTN_Click(object sender, EventArgs e)
        {
            
            this.popuniPodacima();
        }

       
    }
}
