﻿
namespace ParkingGaraza.Forme
{
    partial class ParkingMestaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listaparkingmesta = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.vozilanaparkinguBTN = new System.Windows.Forms.Button();
            this.kategorijeBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listaparkingmesta
            // 
            this.listaparkingmesta.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listaparkingmesta.FullRowSelect = true;
            this.listaparkingmesta.GridLines = true;
            this.listaparkingmesta.HideSelection = false;
            this.listaparkingmesta.Location = new System.Drawing.Point(12, 76);
            this.listaparkingmesta.Name = "listaparkingmesta";
            this.listaparkingmesta.Size = new System.Drawing.Size(338, 346);
            this.listaparkingmesta.TabIndex = 0;
            this.listaparkingmesta.UseCompatibleStateImageBehavior = false;
            this.listaparkingmesta.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Sprat";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 138;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Status";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 131;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(177, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(404, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "LISTA PARKING MESTA";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(505, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(219, 52);
            this.button1.TabIndex = 2;
            this.button1.Text = "Dodaj Parking mesto";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button2.Location = new System.Drawing.Point(505, 168);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(219, 52);
            this.button2.TabIndex = 3;
            this.button2.Text = "Obriši Parking mesto";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // vozilanaparkinguBTN
            // 
            this.vozilanaparkinguBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.vozilanaparkinguBTN.Location = new System.Drawing.Point(505, 249);
            this.vozilanaparkinguBTN.Name = "vozilanaparkinguBTN";
            this.vozilanaparkinguBTN.Size = new System.Drawing.Size(219, 52);
            this.vozilanaparkinguBTN.TabIndex = 5;
            this.vozilanaparkinguBTN.Text = "Vozila na Parkingu";
            this.vozilanaparkinguBTN.UseVisualStyleBackColor = true;
            this.vozilanaparkinguBTN.Click += new System.EventHandler(this.vozilanaparkinguBTN_Click);
            // 
            // kategorijeBTN
            // 
            this.kategorijeBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.kategorijeBTN.Location = new System.Drawing.Point(505, 329);
            this.kategorijeBTN.Name = "kategorijeBTN";
            this.kategorijeBTN.Size = new System.Drawing.Size(219, 52);
            this.kategorijeBTN.TabIndex = 6;
            this.kategorijeBTN.Text = "Kategorije";
            this.kategorijeBTN.UseVisualStyleBackColor = true;
            this.kategorijeBTN.Click += new System.EventHandler(this.kategorijeBTN_Click);
            // 
            // ParkingMestaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.kategorijeBTN);
            this.Controls.Add(this.vozilanaparkinguBTN);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listaparkingmesta);
            this.Name = "ParkingMestaForm";
            this.Text = "ParkingMestaForm";
            this.Load += new System.EventHandler(this.ParkingMestaForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listaparkingmesta;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button vozilanaparkinguBTN;
        private System.Windows.Forms.Button kategorijeBTN;
    }
}