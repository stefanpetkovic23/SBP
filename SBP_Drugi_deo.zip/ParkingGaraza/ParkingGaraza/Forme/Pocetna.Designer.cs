﻿
namespace ParkingGaraza.Forme
{
    partial class Pocetna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.parkingmestaBTN = new System.Windows.Forms.Button();
            this.operateriBTN = new System.Windows.Forms.Button();
            this.korisniciBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label1.Location = new System.Drawing.Point(207, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "PARKING GARAŽA";
            // 
            // parkingmestaBTN
            // 
            this.parkingmestaBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.parkingmestaBTN.Location = new System.Drawing.Point(260, 121);
            this.parkingmestaBTN.Name = "parkingmestaBTN";
            this.parkingmestaBTN.Size = new System.Drawing.Size(258, 50);
            this.parkingmestaBTN.TabIndex = 1;
            this.parkingmestaBTN.Text = "Parking mesta";
            this.parkingmestaBTN.UseVisualStyleBackColor = true;
            this.parkingmestaBTN.Click += new System.EventHandler(this.parkingmestaBTN_Click);
            // 
            // operateriBTN
            // 
            this.operateriBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.operateriBTN.Location = new System.Drawing.Point(260, 205);
            this.operateriBTN.Name = "operateriBTN";
            this.operateriBTN.Size = new System.Drawing.Size(258, 50);
            this.operateriBTN.TabIndex = 2;
            this.operateriBTN.Text = "Operateri";
            this.operateriBTN.UseVisualStyleBackColor = true;
            this.operateriBTN.Click += new System.EventHandler(this.operateriBTN_Click);
            // 
            // korisniciBTN
            // 
            this.korisniciBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.korisniciBTN.Location = new System.Drawing.Point(260, 294);
            this.korisniciBTN.Name = "korisniciBTN";
            this.korisniciBTN.Size = new System.Drawing.Size(258, 50);
            this.korisniciBTN.TabIndex = 3;
            this.korisniciBTN.Text = "Korisnici";
            this.korisniciBTN.UseVisualStyleBackColor = true;
            this.korisniciBTN.Click += new System.EventHandler(this.korisniciBTN_Click);
            // 
            // Pocetna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.korisniciBTN);
            this.Controls.Add(this.operateriBTN);
            this.Controls.Add(this.parkingmestaBTN);
            this.Controls.Add(this.label1);
            this.Name = "Pocetna";
            this.Text = "Pocetna";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button parkingmestaBTN;
        private System.Windows.Forms.Button operateriBTN;
        private System.Windows.Forms.Button korisniciBTN;
    }
}