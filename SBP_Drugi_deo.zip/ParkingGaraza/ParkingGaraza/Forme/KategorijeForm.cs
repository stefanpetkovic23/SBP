﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class KategorijeForm : Form
    {
        public KategorijeForm()
        {
            InitializeComponent();
        }
        private void KategorijeForm_Load()
        {
            this.popuniPodacima();
        }
        public void popuniPodacima()
        {
            listakategorija.Items.Clear();
            List<KategorijaBasic> podaci = DTOManager.GetKategorija();
            foreach (KategorijaBasic k in podaci)
            {
                ListViewItem item = new ListViewItem(new string[] { k.ID.ToString(), k.Velicina_vozila});
                listakategorija.Items.Add(item);
            }
            listakategorija.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.popuniPodacima();
        }
    }
}
