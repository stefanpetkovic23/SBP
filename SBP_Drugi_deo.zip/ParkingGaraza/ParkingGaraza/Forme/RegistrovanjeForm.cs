﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class RegistrovanjeForm : Form
    {
        public RegistrovanjeForm()
        {
            InitializeComponent();
        }

        private void registracijaBTN_Click(object sender, EventArgs e)
        {
            KorisnikBasic korisnik = dodajkorisnika();
            DTOManager.DodajKorisnika(korisnik);
            MessageBox.Show("Upešno ste se registrovali!");
        }
        private KorisnikBasic dodajkorisnika()
        {
            KorisnikBasic korisnik = new KorisnikBasic();
            korisnik.Ime = imeTXB.Text;
            korisnik.Prezime = prezimeTXB.Text;
            korisnik.JMBG = long.Parse(jmbgTXB.Text);

            return korisnik;
        }
    }
}
