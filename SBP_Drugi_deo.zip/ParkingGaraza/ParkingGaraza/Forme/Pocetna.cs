﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class Pocetna : Form
    {
        public Pocetna()
        {
            InitializeComponent();
        }

        private void parkingmestaBTN_Click(object sender, EventArgs e)
        {
            ParkingMestaForm forma = new ParkingMestaForm();
            forma.ShowDialog();
        }

        private void operateriBTN_Click(object sender, EventArgs e)
        {
            OperateriForm forma = new OperateriForm();
            forma.ShowDialog();
        }

        private void korisniciBTN_Click(object sender, EventArgs e)
        {
            KorisniciForm forma = new KorisniciForm();
            forma.ShowDialog();
        }
    }
}
