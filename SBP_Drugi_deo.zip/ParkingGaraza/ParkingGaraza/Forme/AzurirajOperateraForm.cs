﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza.Forme
{
    public partial class AzurirajOperateraForm : Form
    {
        OperaterBasic operater;
        public AzurirajOperateraForm()
        {
            InitializeComponent();
        }
        public AzurirajOperateraForm(OperaterBasic ob)
        {
            InitializeComponent();
            operater = ob;
            popuniPodacima();
        }
        public void popuniPodacima()
        {
            imeTXB.Text = operater.Ime;
            prezimeTXB.Text = operater.Prezime;
            jmbgTBX.Text = operater.JMBG.ToString();
            datumrodjenjadt.Value = operater.Datum_rodjenja;
            datumzaposlenjadt.Value = operater.Datum_zaposlenja;
            radnistazTXB.Text = operater.Radni_staz.ToString();
        }

        private void azurirajBTN_Click(object sender, EventArgs e)
        {
            operater.Ime = imeTXB.Text;
            operater.Prezime = prezimeTXB.Text;
            operater.JMBG = Convert.ToInt64(jmbgTBX.Text);
            operater.Datum_rodjenja = datumrodjenjadt.Value;
            operater.Datum_zaposlenja = datumzaposlenjadt.Value;
            operater.Radni_staz = Int32.Parse(radnistazTXB.Text);

            DTOManager.UpdateOperateraBasic(operater);
            MessageBox.Show("Uspesno ste izmenili operatera!");
            this.Close();
        }
    }
}
