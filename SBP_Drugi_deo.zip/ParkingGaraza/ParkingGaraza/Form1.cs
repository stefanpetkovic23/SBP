﻿using System;
using NHibernate;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingGaraza
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void prikazioperaterabtn_Click(object sender, EventArgs e)
        {
            ISession s = DataLayer.GetSession();
            Entiteti.Operater operater = s.Load<Entiteti.Operater>(8);
            MessageBox.Show("Ime operatera: " + operater.Ime + ", Prezime: " + operater.Prezime+", JMBG: "+operater.JMBG);
            s.Close();
        }

        private void prikazivozilo_Click(object sender, EventArgs e)
        {
            ISession s = DataLayer.GetSession();
            Entiteti.Vozilo vozilo = s.Load<Entiteti.Vozilo>(2);
            MessageBox.Show("Vozilo:" + vozilo.Registarski_broj+", "+vozilo.ID_Karte.Vreme_izdavanja+" Ime vlasnika vozila "+vozilo.ID_Vlasnika.Ime);
            s.Close();
        }

        private void dodajoperatera_Click(object sender, EventArgs e)
        {
            ISession s = DataLayer.GetSession();
            //Entiteti.Operater operater = new Entiteti.Operater();
            //operater.ID = 2;
            //operater.Ime = "Aleksandar";
            //operater.Prezime = "Milic";
            //operater.JMBG = 1006217408791;
            //operater.Datum_rodjenja = new DateTime(1995, 2, 6);
            //operater.Datum_zaposlenja = new DateTime(2016, 8, 8);
            //operater.Radni_staz = 6;

            //Entiteti.ParkingMesto parkingmesto = new Entiteti.ParkingMesto();
            //parkingmesto.Sprat = 7;
            //parkingmesto.Status = "Zauzeto";
            //s.Save(parkingmesto);
            //s.Flush();

            //s.Save(operater);
            //s.Flush();

            //Entiteti.Operater operater = s.Load<Entiteti.Operater>(5);
            //foreach (Entiteti.RFIDKartica k in operater.KarteZaKontrolu)
            //{
            //    MessageBox.Show(k.ID.ToString()+", "+k.ID_Operatera.Ime);
            //}

            List<VoziloBasic> podaci = DTOManager.GetVozila();

            foreach (VoziloBasic vp in podaci)
            {
                MessageBox.Show(vp.ID + ", " + vp.Marka + ", " + vp.Tip+ ", "+vp.Registarski_broj);
                
            }

            //List<ParkingMestoPregled> parkingInfos = DTOManager.GetParkingMestoPregled();
            //foreach (ParkingMestoPregled pm in parkingInfos)
            //{
            //    MessageBox.Show(pm.ID + ", " + pm.Sprat + ", " + pm.Status);
            //}

            //Entiteti.Smena smena = s.Load<Entiteti.Smena>(2);
            //MessageBox.Show("Pocetak smene: " + smena.Pocetak_smene + ", kraj smene" + smena.Kraj_smene + "Operater koji radi u smeni: " + smena.ID_Operatera.Ime + " "+smena.ID_Operatera.Prezime);

            //Entiteti.Korisnik korisnik = s.Load<Entiteti.Korisnik>(4);
            //MessageBox.Show("Ime korisnika: " + korisnik.Ime + ", Prezime korisnika: " + korisnik.Prezime);

            //Entiteti.ParkingMesto parkingmesto = s.Load<Entiteti.ParkingMesto>(3);
            //foreach (Entiteti.Kategorija k in parkingmesto.Kategorije)
            //{ 
            //    MessageBox.Show("Sprat parking mesta: " + parkingmesto.Sprat + ", status parking mesta: " + parkingmesto.Status +k.Velicina_vozila);
            //}

            //List<ParkingMestoPregled> parkingmestoinfo = new List<ParkingMestoPregled>();


            //    IEnumerable<Entiteti.ParkingMesto> parkingmesto = from p in s.Query<Entiteti.ParkingMesto>() select p;
            //    foreach (Entiteti.ParkingMesto p in parkingmesto)
            //    {
            //        parkingmestoinfo.Add(new ParkingMestoPregled(p.ID, p.Sprat, p.Status));
            //        MessageBox.Show(parkingmestoinfo.Count.ToString());
            //    }
            //    foreach (ParkingMestoPregled p in parkingmestoinfo)
            //    {
            //    MessageBox.Show(p.ID.ToString() + ", " + p.Sprat.ToString() + ", " + p.Status);
            //    }

            //Entiteti.Pojedinacna pojedinacna = s.Load<Entiteti.Pojedinacna>(4);
            //MessageBox.Show("Status parking mesta na koji se odnosi karta:" + pojedinacna.ID_parking_mesta.Status);

            //Entiteti.Pretplatna pretplatna = s.Load<Entiteti.Pretplatna>(1);
            //MessageBox.Show("Karta rezervisana za parking mesto:" + pretplatna.Rezervisano_mesto + ", korisnik parkinga: " + pretplatna.ID_Korisnika.ID);

            //Entiteti.RFIDKartica karta = s.Load<Entiteti.RFIDKartica>(2);
            //MessageBox.Show("Operater je proverio karticu:" + karta.ID_Operatera.Ime);

            s.Close();
           
            

        }
    }
}
