﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class RFIDKartica
    {
        public virtual int ID { get; set; }
        public virtual Operater ID_Operatera { get; set; }
    }
}
