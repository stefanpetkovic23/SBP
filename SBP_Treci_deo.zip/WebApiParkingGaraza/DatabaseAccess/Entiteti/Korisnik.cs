﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Korisnik:Osoba
    {
        public virtual long JMBG { get; set; }

        public virtual IList<Pretplatna> ListaPretplatnih { get; set; }

        public Korisnik()
        {
            ListaPretplatnih = new List<Pretplatna>();
        }
    }
}
