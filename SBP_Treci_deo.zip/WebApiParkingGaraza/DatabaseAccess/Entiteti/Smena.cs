﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Smena
    {
        public virtual int ID { get; set; }
        public virtual int Pocetak_smene { get; set; }
        public virtual int Kraj_smene { get; set; }
        public virtual Operater ID_Operatera { get; set; }
        public virtual Kontroler ID_Kontrolera { get; set; }
    }
}
