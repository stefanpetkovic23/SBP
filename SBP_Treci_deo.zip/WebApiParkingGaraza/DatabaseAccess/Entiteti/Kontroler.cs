﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Kontroler:Operater
    {
        public virtual int Vreme_rada { get; set; }

        public virtual IList<Smena> SmeneKontrolera { get; set; }

        public Kontroler() 
        {
            SmeneKontrolera = new List<Smena>();
        }
    }
}
