﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Pretplatna:RFIDKartica
    {
        public virtual string Rezervisano_mesto { get; set; }
        public virtual int Vreme_vazenja_parkinga { get; set; }
        public virtual Korisnik ID_Korisnika { get; set; }
        public virtual IList<Vozilo> ListaVozila { get; set; }

        public Pretplatna() 
        {
            ListaVozila = new List<Vozilo>();
        }
    }
}
