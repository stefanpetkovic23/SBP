﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class ParkingMesto
    {
        public virtual int ID { get; set; }

        public virtual int Sprat { get; set; }

        public virtual string Status { get; set; }

       public virtual IList<Kategorija> Kategorije { get; set; }

        public ParkingMesto()
        {
            Kategorije = new List<Kategorija>();
        }
    }
}
