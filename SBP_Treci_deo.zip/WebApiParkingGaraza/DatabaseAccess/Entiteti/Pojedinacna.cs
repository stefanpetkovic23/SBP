﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Entiteti
{
    public class Pojedinacna:RFIDKartica
    {
        public virtual string Registarska_oznaka_vozila { get; set; }
        public virtual DateTime Vreme_izdavanja { get; set; }
        public virtual DateTime Vreme_izlaska { get; set; }
        public virtual ParkingMesto ID_parking_mesta { get; set; }
    }
}
