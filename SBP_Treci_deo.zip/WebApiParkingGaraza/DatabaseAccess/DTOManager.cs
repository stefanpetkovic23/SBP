﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using ParkingGaraza.Entiteti;
using System.Threading.Tasks;
using DatabaseAccess;

namespace DatabaseAccess
{
    public static class DTOManager
    {
        public static List<ParkingMestoBasic> GetParkingMestoPregled()
        {
            List<ParkingMestoBasic> parkingmestoinfo = new List<ParkingMestoBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.ParkingMesto> parkingmesto = from p in s.Query<ParkingGaraza.Entiteti.ParkingMesto>() select p;
                foreach (ParkingMesto p in parkingmesto)
                {
                    
                    parkingmestoinfo.Add(new ParkingMestoBasic(p.ID, p.Sprat, p.Status));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }

            return parkingmestoinfo;
        }
        //public static List<ParkingMestoBasic> GetParkingMestoPregledV2()
        //{
        //    List<ParkingMestoBasic> parkingmestoinfo = new List<ParkingMestoBasic>();
        //    try
        //    {
        //        ISession s = DataLayer.GetSession();
        //        List<ParkingMesto> list = s.Query<ParkingMesto>().ToList();
        //        ParkingMestoBasic retSingle;
        //        ParkingMesto p;
        //        list.ForEach(p =>
        //        {
        //            retSingle = new ParkingMestoBasic();

        //            retSingle.Id = p.ID;
        //            retSingle.Sprat = p.Sprat;
        //            retSingle.Status = p.Status;
        //            retSingle.Kategorije =GetAllKategorija(p);

        //            parkingmestoinfo.Add(retSingle);
        //        });

        //        s.Close();
        //    }
        //    catch (Exception ec)
        //    {

        //    }

        //    return parkingmestoinfo;
        //}
        public static void UpdateParkingMesto(ParkingMestoPregled pm)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.ParkingMesto parkingmesto = s.Load<ParkingGaraza.Entiteti.ParkingMesto>(pm.ID);
                parkingmesto.Sprat = pm.Sprat;
                parkingmesto.Status = pm.Status;

                s.Update(parkingmesto);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static ParkingMestoPregled DodajParkingMesto(ParkingMestoPregled pm)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.ParkingMesto parkingMesto = new ParkingGaraza.Entiteti.ParkingMesto();
                parkingMesto.Sprat = pm.Sprat;
                parkingMesto.Status = pm.Status;

                s.Save(parkingMesto);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }

            return pm;
        }
        public static void DeleteParkingMesto(int ID)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.ParkingMesto p = s.Load<ParkingGaraza.Entiteti.ParkingMesto>(ID);

                s.Delete(p);
                s.Flush();

                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<ParkingMestoBasic> GetParkingMestoBasic()
        {
            List<ParkingMestoBasic> parkinginfo = new List<ParkingMestoBasic>();
            try
            {
                ISession s = DataLayer.GetSession();

                IEnumerable<ParkingGaraza.Entiteti.ParkingMesto> parking = from p in s.Query<ParkingGaraza.Entiteti.ParkingMesto>()where p.Status=="Slobodno" select p;

                foreach (ParkingGaraza.Entiteti.ParkingMesto p in parking)
                {
                    parkinginfo.Add(new ParkingMestoBasic(p.ID, p.Sprat, p.Status));
                }

                s.Close();
            }
            catch (Exception ec)
            {
                
            }
            return parkinginfo;
        }
        public static List<OperaterPregled> GetOperateraPregled()
        {
            List<OperaterPregled> operaterinfo = new List<OperaterPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Operater> operaters = from p in s.Query<ParkingGaraza.Entiteti.Operater>() select p;
                foreach (Operater p in operaters)
                {
                    operaterinfo.Add(new OperaterPregled(p.ID,p.JMBG,p.Ime,p.Prezime,p.Datum_rodjenja,p.Datum_zaposlenja,p.Radni_staz));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return operaterinfo;
        }
        public static List<OperaterBasic> getOperater()
        {
            List<OperaterBasic> operaterinfo = new List<OperaterBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Operater> operaters = from p in s.Query<ParkingGaraza.Entiteti.Operater>() select p;
                foreach (Operater p in operaters)
                {
                    var Operater = new OperaterBasic();
                   // Operater.SmeneOperatera = p.SmeneOperatera.Select(p => new SmenaPregled()).ToList();
                    Operater.ID = p.ID;
                    Operater.JMBG = p.JMBG;
                    Operater.Ime = p.Ime;
                    Operater.Prezime = p.Prezime;
                    Operater.Datum_rodjenja = p.Datum_rodjenja;
                    Operater.Datum_zaposlenja = p.Datum_zaposlenja;
                    Operater.Radni_staz = p.Radni_staz;
                    operaterinfo.Add(Operater);
                    //operaterinfo.Add(new OperaterBasic(p.ID, p.JMBG, p.Ime, p.Prezime, p.Datum_rodjenja, p.Datum_zaposlenja, p.Radni_staz));
                }
                

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return operaterinfo;
        }
        public static void DodajOperatera( OperaterPregled op)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Operater operater = new ParkingGaraza.Entiteti.Operater();
                operater.JMBG = op.JMBG;
                operater.Ime = op.Ime;
                operater.Prezime = op.Prezime;
                operater.Datum_rodjenja = op.Datum_rodjenja;
                operater.Datum_zaposlenja = op.Datum_zaposlenja;
                operater.Radni_staz = op.Radni_staz;

                s.Save(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static void DeleteOperatera(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Operater operater = s.Load<ParkingGaraza.Entiteti.Operater>(id);

                s.Delete(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdateOperateraBasic(OperaterBasic ob)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Operater operater = s.Load<ParkingGaraza.Entiteti.Operater>(ob.ID);
                operater.JMBG = ob.JMBG;
                operater.Ime = ob.Ime;
                operater.Prezime = ob.Prezime;
                operater.Datum_rodjenja = ob.Datum_rodjenja;
                operater.Datum_zaposlenja = ob.Datum_zaposlenja;
                operater.Radni_staz = ob.Radni_staz;

                s.Update(operater);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<KontrolerBasic> GetKontrolera()
        {
            List<KontrolerBasic> kontrolerinfo = new List<KontrolerBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Kontroler> operaters = from p in s.Query<ParkingGaraza.Entiteti.Kontroler>() select p;
                foreach (Kontroler p in operaters)
                {
                    kontrolerinfo.Add(new KontrolerBasic(p.ID, p.JMBG, p.Ime, p.Prezime, p.Datum_rodjenja, p.Datum_zaposlenja, p.Radni_staz,p.Vreme_rada));
                }

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return kontrolerinfo;
        }
        public static void UpdateKontroleraBasic(KontrolerBasic ob)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Kontroler kontroler = s.Load<ParkingGaraza.Entiteti.Kontroler>(ob.ID);
                kontroler.JMBG = ob.JMBG;
                kontroler.Ime = ob.Ime;
                kontroler.Prezime = ob.Prezime;
                kontroler.Datum_rodjenja = ob.Datum_rodjenja;
                kontroler.Datum_zaposlenja = ob.Datum_zaposlenja;
                kontroler.Radni_staz = ob.Radni_staz;
                kontroler.Vreme_rada = ob.Vreme_rada;

                s.Update(kontroler);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DodajKontrolera(KontrolerBasic kon)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Kontroler kontroler = new Kontroler();
                kontroler.JMBG = kon.JMBG;
                kontroler.Ime = kon.Ime;
                kontroler.Prezime = kon.Prezime;
                kontroler.Datum_rodjenja = kon.Datum_rodjenja;
                kontroler.Datum_zaposlenja = kon.Datum_zaposlenja;
                kontroler.Vreme_rada = kon.Vreme_rada;
                kontroler.Radni_staz = kon.Radni_staz;

                s.SaveOrUpdate(kontroler);
                s.Flush();
                s.Close();

            }
            catch (Exception ec)
            {

            }
        }
        public static void DeleteKontrolera(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Kontroler kontroler = s.Load<ParkingGaraza.Entiteti.Kontroler>(id);

                s.Delete(kontroler);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static List<VoziloBasic> GetVozila()
        {
            List<VoziloBasic> listavozilapregled = new List<VoziloBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Vozilo> listavozila = from p in s.Query<ParkingGaraza.Entiteti.Vozilo>() select p;

                foreach (Vozilo v in listavozila)
                {
                    listavozilapregled.Add(new VoziloBasic(v));

                    s.Close();
                }
            }
            catch (Exception ec)
            {
                
            }
            return listavozilapregled;
        }
        public static List<VoziloPregled> GetVozilaPregled()
        {
            List<VoziloPregled> listavozilapregled = new List<VoziloPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Vozilo> listavozila = from p in s.Query<ParkingGaraza.Entiteti.Vozilo>() select p;

                foreach (Vozilo v in listavozila)
                {
                    listavozilapregled.Add(new VoziloPregled(v.ID, v.Marka, v.Tip, v.Registarski_broj));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return listavozilapregled;
        }
        public static void DodajVozilo(VoziloPregled vb, int vlasinkid, int kartaid)
        {
            ParkingGaraza.Entiteti.Vozilo vozilo = new Vozilo();
            try
            {
                ISession s = DataLayer.GetSession();
                

                vozilo.Marka = vb.Marka;
                vozilo.Tip = vb.Tip;
                vozilo.Registarski_broj = vb.Registarski_broj;
                vozilo.ID_Vlasnika = s.Load<ParkingGaraza.Entiteti.Vlasnik>(vlasinkid);
                vozilo.ID_Karte = s.Load<ParkingGaraza.Entiteti.Pojedinacna>(kartaid);

                s.Save(vozilo);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static void UpdateVozilo(VoziloPregled vb)
        {
            ParkingGaraza.Entiteti.Vozilo vozilo = new Vozilo();
            try
            {
                ISession s = DataLayer.GetSession();


                vozilo.Marka = vb.Marka;
                vozilo.Tip = vb.Tip;
                vozilo.Registarski_broj = vb.Registarski_broj;
                
                s.Update(vozilo);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeleteVozilo(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Vozilo vozilo = s.Load<ParkingGaraza.Entiteti.Vozilo>(id);

                s.Delete(vozilo);
                s.Flush();
                s.Close();

            }
            catch (Exception ec)
            {

            }
        }
        public static OsobaBasic GetOsoba(int id)
        {
            OsobaBasic osoba = new OsobaBasic();
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Osoba o = s.Load<ParkingGaraza.Entiteti.Osoba>(id);
                osoba = new OsobaBasic(o.ID, o.Ime, o.Prezime);

                s.Close();
            }
            catch (Exception ec)
            {

            }

            return osoba;
        }
        public static List<OsobaBasic> GetOsobePregled()
        {
            List<OsobaBasic> listaosobapregled = new List<OsobaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Osoba> listaosoba = from p in s.Query<ParkingGaraza.Entiteti.Osoba>() select p;

                foreach (Osoba v in listaosoba)
                {
                    listaosobapregled.Add(new OsobaBasic(v.ID, v.Ime, v.Prezime));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return listaosobapregled;
        }
        public static List<KorisnikBasic> GetKorisnikPregled()
        {
            List<KorisnikBasic> listaosobapregled = new List<KorisnikBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<Korisnik> listaosoba = from p in s.Query<ParkingGaraza.Entiteti.Korisnik>() select p;

                foreach (Korisnik v in listaosoba)
                {
                    listaosobapregled.Add(new KorisnikBasic(v.ID, v.Ime, v.Prezime,v.JMBG));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return listaosobapregled;
        }
        public static void DodajKorisnika(KorisnikBasic kb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Korisnik korisnik = new Korisnik();
                korisnik.Ime = kb.Ime;
                korisnik.Prezime = kb.Prezime;
                korisnik.JMBG = kb.JMBG;

                s.Save(korisnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec) 
            {

            }
        }
        public static void DeleteKorisnika(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Korisnik korisnik = s.Load<ParkingGaraza.Entiteti.Korisnik>(id);

                s.Delete(korisnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdateKorisnika(KorisnikBasic kb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Korisnik korisnik = s.Load<ParkingGaraza.Entiteti.Korisnik>(kb.ID);
                korisnik.Ime = kb.Ime;
                korisnik.Prezime = kb.Prezime;
                korisnik.JMBG = kb.JMBG;

                s.Save(korisnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static int GetIDKorisnika(int jmbg)
        {
            int IDKorisnika = 0;
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Korisnik> korisnici = from o in s.Query<ParkingGaraza.Entiteti.Korisnik>() where o.JMBG == jmbg select o;

                foreach(Korisnik k in korisnici)
                {
                    IDKorisnika = k.ID;
                }
            }
            catch (Exception ec)
            {

            }
            return IDKorisnika;
        }
        public static void DodajVlasnika(VlasnikBasic vb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Vlasnik vlasnik = new Vlasnik();
                vlasnik.Ime = vb.Ime;
                vlasnik.Prezime = vb.Prezime;

                s.Save(vlasnik);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
        }
        public static int GetIDVlasnika(int id)
        {
            int IDVlasnika = 0;
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Vlasnik> vlasnici = from o in s.Query<ParkingGaraza.Entiteti.Vlasnik>() where o.ID == id select o;

                foreach (Vlasnik v in vlasnici)
                {
                    IDVlasnika = v.ID;
                }
            }
            catch (Exception ec)
            {
                
            }
            return IDVlasnika;
        }
        public static Pretplatna GetPretplatna(int id)
        {
            Pretplatna p = new Pretplatna();
            try
            {
                ISession s = DataLayer.GetSession();

                p = s.Load<ParkingGaraza.Entiteti.Pretplatna>(id);

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return p;
        }
        public static void DodajPretplatnu(PretplatnaPregled pb, int korisnikid)
        {
            ParkingGaraza.Entiteti.Pretplatna pretplatna = new ParkingGaraza.Entiteti.Pretplatna();
            try
            {
                ISession s = DataLayer.GetSession();
                

                pretplatna.Rezervisano_mesto = pb.Rezervisano_mesto;
                pretplatna.Vreme_vazenja_parkinga = pb.Vreme_vazenja_karte;
                pretplatna.ID_Korisnika = s.Load<ParkingGaraza.Entiteti.Korisnik>(korisnikid);

                s.Save(pretplatna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdatePretplatnu(PretplatnaPregled pb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Pretplatna pretplatna = s.Load<ParkingGaraza.Entiteti.Pretplatna>(pb.ID); ;

                pretplatna.Rezervisano_mesto = pb.Rezervisano_mesto;
                pretplatna.Vreme_vazenja_parkinga = pb.Vreme_vazenja_karte;
                
                s.Update(pretplatna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeletePretplatnu(int id)
        {
            try 
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Pretplatna pretplatna = s.Load<ParkingGaraza.Entiteti.Pretplatna>(id);

                s.Delete(pretplatna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static List<PretplatnaBasic> GetPretplatnaBasic()
        {
            List<PretplatnaBasic> pretplatnekarte = new List<PretplatnaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Pretplatna> karta = from k in s.Query<ParkingGaraza.Entiteti.Pretplatna>() select k;

                foreach (Pretplatna p in karta)
                {
                    pretplatnekarte.Add(new PretplatnaBasic(p.ID, p.ID_Operatera, p.Rezervisano_mesto, p.Vreme_vazenja_parkinga, p.ID_Korisnika));
                }
                s.Close();
            }
            catch (Exception ec)
            {

            }
            return pretplatnekarte;
        }
        public static List<PretplatnaPregled> GetPretplatnaPregled()
        {
            List<PretplatnaPregled> pretplatnekarte = new List<PretplatnaPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Pretplatna> karta = from k in s.Query<ParkingGaraza.Entiteti.Pretplatna>() select k;

                foreach (Pretplatna p in karta)
                {
                    pretplatnekarte.Add(new PretplatnaPregled(p.ID, p.ID_Operatera, p.Rezervisano_mesto, p.Vreme_vazenja_parkinga));
                }
                s.Close();
            }
            catch (Exception ec)
            {

            }
            return pretplatnekarte;
        }
        public static Pojedinacna GetPojedinacna(int id)
        {
            Pojedinacna p = new Pojedinacna();
            try 
            {
                ISession s = DataLayer.GetSession();

                p = s.Load<ParkingGaraza.Entiteti.Pojedinacna>(id);

                s.Close();
            }
            catch (Exception ec)
            {

            }
            return p;
        }
        public static void DodajPojedinacnu(PojedinacnaPregled pb, int parkingmestoid)
        {
            ParkingGaraza.Entiteti.Pojedinacna pojedinacna = new ParkingGaraza.Entiteti.Pojedinacna();
            try 
            {
                ISession s = DataLayer.GetSession();
                
                pojedinacna.Registarska_oznaka_vozila = pb.Registarska_oznaka_vozila;
                pojedinacna.Vreme_izdavanja = pb.Vreme_izdavanja;
                pojedinacna.Vreme_izlaska = pb.Vreme_izlaska;
                pojedinacna.ID_parking_mesta = s.Load<ParkingGaraza.Entiteti.ParkingMesto>(parkingmestoid);

                s.Save(pojedinacna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdatePojedinacnu(PojedinacnaPregled pb)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Pojedinacna pojedinacna = s.Load<ParkingGaraza.Entiteti.Pojedinacna>(pb.ID);
                pojedinacna.Registarska_oznaka_vozila = pb.Registarska_oznaka_vozila;
                pojedinacna.Vreme_izdavanja = pb.Vreme_izdavanja;
                pojedinacna.Vreme_izlaska = pb.Vreme_izlaska;
                

                s.Save(pojedinacna);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeletePojedinacnu(int id)
        {
            try 
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Pojedinacna pojedinacna = s.Load<ParkingGaraza.Entiteti.Pojedinacna>(id);

                s.Delete(pojedinacna);
                s.Flush();
                s.Close();
            }
            catch 
            { }
        }
        public static List<PojedinacnaBasic> GetPojedinacnaBasic()
        {
            List<PojedinacnaBasic> pojedinacnekarte = new List<PojedinacnaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Pojedinacna> karta = from k in s.Query<ParkingGaraza.Entiteti.Pojedinacna>() select k;

                foreach (Pojedinacna p in karta)
                {
                    pojedinacnekarte.Add(new PojedinacnaBasic(p.ID, p.ID_Operatera, p.Registarska_oznaka_vozila, p.Vreme_izdavanja, p.Vreme_izlaska, p.ID_parking_mesta));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return pojedinacnekarte;
        }
        public static List<PojedinacnaPregled> GetPojedinacnaPregled()
        {
            List < PojedinacnaPregled> pojedinacnekarte = new List<PojedinacnaPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Pojedinacna> karta = from k in s.Query<ParkingGaraza.Entiteti.Pojedinacna>() select k;

                foreach (Pojedinacna p in karta)
                {
                    pojedinacnekarte.Add(new PojedinacnaPregled(p.ID, p.ID_Operatera, p.Registarska_oznaka_vozila, p.Vreme_izdavanja, p.Vreme_izlaska));

                    s.Close();
                }
            }
            catch (Exception ec)
            {

            }
            return pojedinacnekarte;
        }
        public static List<KategorijaBasic> GetKategorija()
        {
            List<KategorijaBasic> kategorije = new List<KategorijaBasic>();

            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Kategorija> kategorija = from k in s.Query<ParkingGaraza.Entiteti.Kategorija>() select k;

                foreach (ParkingGaraza.Entiteti.Kategorija k in kategorija)
                {
                    kategorije.Add(new KategorijaBasic(k));
                }
                s.Close();
            }
            catch (Exception ec)
            {
                
            }
            return kategorije;
        }
        public static List<Kategorija> GetAllKategorija()
        {
            List<Kategorija> kategorije = new List<Kategorija>();

            try
            {
                ISession s = DataLayer.GetSession();
                List<Kategorija> list = s.Query<Kategorija>()
               
                   .ToList();

                Kategorija retSingle;

                list.ForEach(p =>
                {
                    retSingle = new Kategorija();

                    retSingle.ID = p.ID;
                    retSingle.Velicina_vozila = p.Velicina_vozila;
                    retSingle.ID_Parking_mesta = p.ID_Parking_mesta;

                    kategorije.Add(retSingle);
                });
                s.Close();
            }
            catch (Exception ec)
            {

            }
            return kategorije;
        }
        public static List<KategorijaPregled> GetKategorijaPregled()
        {
            List < KategorijaPregled> kategorije = new List<KategorijaPregled>();

            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Kategorija> kategorija = from k in s.Query<ParkingGaraza.Entiteti.Kategorija>() select k;

                foreach (ParkingGaraza.Entiteti.Kategorija k in kategorija)
                {
                    kategorije.Add(new KategorijaPregled(k.ID, k.Velicina_vozila));
                }
                s.Close();
            }
            catch (Exception ec)
            {

            }
            return kategorije;
        }
        public static void DodajKategoriju(KategorijaBasic kb,int parkinmestoid)
        {
            Kategorija kategorija = new Kategorija();
            try
            {
                ISession s = DataLayer.GetSession();
                kategorija.Velicina_vozila = kb.Velicina_vozila;
                kategorija.ID_Parking_mesta = s.Load<ParkingGaraza.Entiteti.ParkingMesto>(parkinmestoid);

                s.SaveOrUpdate(kategorija);
                s.Flush();
                s.Close();
            }
            catch (Exception ec) 
            {

            }
        }
        public static void UpdateKategoriju(KategorijaBasic kb)
        {
           
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Kategorija kategorija = s.Load<ParkingGaraza.Entiteti.Kategorija>(kb.ID);
                kategorija.Velicina_vozila = kb.Velicina_vozila;       

                s.Update(kategorija);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DeleteKategoriju(int id)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Kategorija kategorija = s.Load<ParkingGaraza.Entiteti.Kategorija>(id);

                s.Delete(kategorija);
                s.Flush();
                s.Close();
            }
            catch
            { }
        }
        public static bool DaLiJePretplatna(int id)
        {
            bool t = true;
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Pretplatna pretplatna = s.Load<ParkingGaraza.Entiteti.Pretplatna>(id);

                s.Close();
            }
            catch (Exception ec)
            {
                t = false;
            }
            return t;
        }
        public static bool DaLiJeSlobodnoParkingmesto(int id)
        {
            bool t = true;
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.ParkingMesto parkingmesto = s.Load<ParkingGaraza.Entiteti.ParkingMesto>(id);
                if (parkingmesto.Status == "Slobodno")
                {
                    t = true;
                }
                else
                    t = false;
            }
            catch (Exception ec)
            { 

            }
            return t;
        }
        public static List<SmenaBasic> GetSmena()
        {
            List<SmenaBasic> smene = new List<SmenaBasic>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Smena> smena = from k in s.Query<ParkingGaraza.Entiteti.Smena>() select k;

                foreach (ParkingGaraza.Entiteti.Smena sm in smena)
                {
                    smene.Add(new SmenaBasic(sm));
                }

                s.Close();
            }
            catch (Exception)
            {

            }

            return smene;
        }
        public static List<SmenaPregled> GetSmenaPregled()
        {
            List<SmenaPregled> smene = new List<SmenaPregled>();
            try
            {
                ISession s = DataLayer.GetSession();
                IEnumerable<ParkingGaraza.Entiteti.Smena> smena = from k in s.Query<ParkingGaraza.Entiteti.Smena>() select k;

                foreach (ParkingGaraza.Entiteti.Smena sm in smena)
                {
                    smene.Add(new SmenaPregled(sm.ID, sm.Pocetak_smene, sm.Kraj_smene));
                }

                s.Close();
            }
            catch (Exception)
            {

            }

            return smene;
        }
        public static void DeleteSmena(int ID)
        {
            try
            {
                ISession s = DataLayer.GetSession();
                ParkingGaraza.Entiteti.Smena p = s.Load<ParkingGaraza.Entiteti.Smena>(ID);

                s.Delete(p);
                s.Flush();

                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void DodajSmenu(SmenaPregled kb, int operatorid)
        {
            Smena smena = new Smena();
            try
            {
                ISession s = DataLayer.GetSession();

                smena.Pocetak_smene = kb.Pocetak_smene;
                smena.Kraj_smene = kb.Kraj_smene;
                smena.ID_Operatera= s.Load<ParkingGaraza.Entiteti.Operater>(operatorid);
                smena.ID_Kontrolera = s.Load<ParkingGaraza.Entiteti.Kontroler>(operatorid);

                s.SaveOrUpdate(smena);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
        public static void UpdateSmenu(SmenaBasic kb)
        {
            Smena smena = new Smena();
            try
            {
                ISession s = DataLayer.GetSession();

                smena.Pocetak_smene = kb.Pocetak_smene;
                smena.Kraj_smene = kb.Kraj_smene;
                

                s.Update(smena);
                s.Flush();
                s.Close();
            }
            catch (Exception ec)
            {

            }
        }
    }

    
}
