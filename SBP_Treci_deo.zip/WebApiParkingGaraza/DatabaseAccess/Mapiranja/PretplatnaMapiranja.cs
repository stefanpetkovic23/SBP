﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class PretplatnaMapiranja:ClassMap<Pretplatna>
    {
        public PretplatnaMapiranja() {

            Table("PRETPLATNA");

            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Rezervisano_mesto, "REZERVISANO_MESTO");
            Map(x => x.Vreme_vazenja_parkinga, "VREME_VAZENJA_PARKINGA");
            HasMany(x => x.ListaVozila).KeyColumn("ID_KORISNIKA").Inverse().Cascade.All();
        }
    }
}
