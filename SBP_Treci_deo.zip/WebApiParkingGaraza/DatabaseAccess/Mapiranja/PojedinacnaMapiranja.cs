﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using ParkingGaraza.Entiteti;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class PojedinacnaMapiranja:ClassMap<Pojedinacna>
    {
        public PojedinacnaMapiranja() {

            Table("POJEDINACNA");
            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Registarska_oznaka_vozila, "REGISTARSKA_OZNAKA_VOZILA");
            Map(x => x.Vreme_izdavanja, "VREME_IZDAVANJA");
            Map(x => x.Vreme_izlaska, "VREME_IZLASKA");
            References(x => x.ID_parking_mesta).Column("ID_PARKING_MESTA").LazyLoad();
        }
    }
}
