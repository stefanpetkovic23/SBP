﻿using FluentNHibernate.Mapping;
using System;
using ParkingGaraza.Entiteti;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class SmenaMapiranja:ClassMap<Smena>
    {
        public SmenaMapiranja() {

            Table("SMENA");

            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();
            Map(x => x.Pocetak_smene, "POCETAK_SMENE");
            Map(x => x.Kraj_smene, "KRAJ_SMENE");
            References(x => x.ID_Operatera).Column("ID_OPERATERA").LazyLoad();
            References(x => x.ID_Kontrolera).Column("ID_KONTROLERA").LazyLoad();
        }
    }
}
