﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ParkingGaraza.Entiteti;
using System.Threading.Tasks;

namespace ParkingGaraza.Mapiranja
{
    public class ParkingMestoMapiranja : ClassMap<ParkingMesto>
    {
        public ParkingMestoMapiranja() {

            Table("PARKING_MESTO");

            Id(x => x.ID, "ID").GeneratedBy.TriggerIdentity();

            Map(x => x.Sprat, "SPRAT");
            Map(x => x.Status, "STATUS");
            HasMany(x => x.Kategorije).KeyColumn("ID_PARKING_MESTA").Inverse().Cascade.All();
           
        }
    }
}
