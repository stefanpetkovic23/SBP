﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ParkingMestoController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiParkingMesta")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllParkingMesta()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetParkingMestoPregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajParkingMesto")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddParkingMesto([FromBody] DatabaseAccess.ParkingMestoPregled o)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajParkingMesto(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("AzurirajParkingMesto")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateParkingMesto([FromBody] DatabaseAccess.ParkingMestoPregled o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateParkingMesto(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiParkingMesto/{ID}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteParkingMesto(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteParkingMesto(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
