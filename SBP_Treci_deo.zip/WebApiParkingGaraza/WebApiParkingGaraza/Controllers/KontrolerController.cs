﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class KontrolerController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiKontrolere")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllKontroler()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetKontrolera());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniKontrolera/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateKontroler([FromBody] DatabaseAccess.KontrolerBasic o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateKontroleraBasic(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajKontrolera")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddKontroler([FromBody] DatabaseAccess.KontrolerBasic o)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajKontrolera(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiKontrolera/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteKontroler(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteKontrolera(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
