﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class KorisnikController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiKorisnike")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllKorisnici()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetKorisnikPregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }

        }

        [HttpPost]
        [Route("DodajKorisnika")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddKorisnik([FromBody] DatabaseAccess.KorisnikBasic o)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajKorisnika(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniKorisnika")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateKorisnik([FromBody] DatabaseAccess.KorisnikBasic o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateKorisnika(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiKorisnika/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteKorisnik(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteKorisnika(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
