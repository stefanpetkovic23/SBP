﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SmenaController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiSmene")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllSmena()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetSmena());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiSmenu/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteSmena(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteSmena(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajSmenu/{operaterid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddSmena([FromBody] DatabaseAccess.SmenaPregled s, int operaterid)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajSmenu(s,operaterid);
                return new JsonResult(s);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniSmenu")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateSmena([FromBody] DatabaseAccess.SmenaBasic s)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateSmenu(s);
                return new JsonResult(s);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
