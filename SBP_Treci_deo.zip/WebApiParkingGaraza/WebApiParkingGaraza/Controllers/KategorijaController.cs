﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class KategorijaController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiKategorije")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllKategorija()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetKategorija());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajKategoriju/{parkingmestoid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddKategorija([FromBody] DatabaseAccess.KategorijaBasic k, int parkingmestoid)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajKategoriju(k,parkingmestoid);
                return new JsonResult(k);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiKategoriju/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteKategorija(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteKategoriju(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniKategoriju")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateKategorija([FromBody] DatabaseAccess.KategorijaBasic k)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateKategoriju(k);
                return new JsonResult(k);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
