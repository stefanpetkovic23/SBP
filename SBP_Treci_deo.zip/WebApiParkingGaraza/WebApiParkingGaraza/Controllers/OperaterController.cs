﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OperaterController : ControllerBase
    {
        public OperaterController()
        {
        }

        [HttpGet]
        [Route("PreuzmiOperatere")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllOperateri()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.getOperater());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniOperatera")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateOperater([FromBody] DatabaseAccess.OperaterBasic o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateOperateraBasic(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajOperatera")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddOperater([FromBody] DatabaseAccess.OperaterPregled o)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajOperatera(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiOperatera/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteOperater(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteOperatera(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
