﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class VoziloController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiVozila")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllVozila()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetVozilaPregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniVozilo")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdateVozilo([FromBody] DatabaseAccess.VoziloPregled v)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdateVozilo(v);
                return new JsonResult(v);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajVozilo/{kartaid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddVozilo([FromBody] DatabaseAccess.VoziloPregled v, int vlasinkid,int kartaid)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajVozilo(v,vlasinkid,kartaid);
                return new JsonResult(v);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiVozilo/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteVozilo(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeleteVozilo(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
