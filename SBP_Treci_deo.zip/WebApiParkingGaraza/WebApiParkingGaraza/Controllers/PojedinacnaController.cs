﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PojedinacnaController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiPojedinacne")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllPojedinacna()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetPojedinacnaPregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajPojedinacnu/{parkingmestoid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddPojedinacna([FromBody] DatabaseAccess.PojedinacnaPregled o, int parkingmestoid)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajPojedinacnu(o,parkingmestoid);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniPojedinacnu")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdatePojedinacna([FromBody] DatabaseAccess.PojedinacnaPregled o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdatePojedinacnu(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiPojedinacnu/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeletePojedinacna(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeletePojedinacnu(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
