﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class OsobaController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiOsobe")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllAdministracija()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetOsobePregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
