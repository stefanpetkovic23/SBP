﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiParkingGaraza.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PretplatnaController : ControllerBase
    {
        [HttpGet]
        [Route("PreuzmiPretplatne")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllPretplatna()
        {
            try
            {
                return new JsonResult(DatabaseAccess.DTOManager.GetPretplatnaPregled());
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPost]
        [Route("DodajPretplatnu/{korisnikid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult AddPretplatna([FromBody] DatabaseAccess.PretplatnaPregled o, int korisnikid)
        {
            try
            {
                DatabaseAccess.DTOManager.DodajPretplatnu(o,korisnikid);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpPut]
        [Route("IzmeniPretplatnu")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult UpdatePretplatna([FromBody] DatabaseAccess.PretplatnaPregled o)
        {
            try
            {
                DatabaseAccess.DTOManager.UpdatePretplatnu(o);
                return new JsonResult(o);
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }

        [HttpDelete]
        [Route("ObrisiPretplatnu/{id}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeletePretplatna(int id)
        {
            try
            {
                DatabaseAccess.DTOManager.DeletePretplatnu(id);
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.ToString());
            }
        }
    }
}
